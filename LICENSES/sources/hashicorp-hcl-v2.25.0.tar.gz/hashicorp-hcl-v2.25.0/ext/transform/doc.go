// Copyright IBM Corp. 2014, 2025
// SPDX-License-Identifier: MPL-2.0

// Package transform is a helper package for writing extensions that work
// by applying transforms to bodies.
//
// It defines a type for body transformers, and then provides utilities in
// terms of that type for working with transformers, including recursively
// applying such transforms as heirarchical block structures are extracted.
package transform
