module "foo" {
  source = "./foo"
}
