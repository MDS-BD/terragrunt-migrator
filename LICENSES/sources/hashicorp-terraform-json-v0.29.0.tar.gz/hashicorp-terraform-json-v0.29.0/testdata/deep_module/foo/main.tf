module "bar" {
  source = "./bar"
}
